<?php
// [추가함] 팝업창(iframe)으로 열렸을 때 메뉴바, 푸터 숨기기
if(isset($_GET['iframe_mode']) && $_GET['iframe_mode'] == '1') {
    echo '<style>
        header, footer, #hd, #ft, .gnb_wrap, #hd_pop, .hd_pop, #tnb, .sound_only, #side, .hd_login, .ft { display: none !important; } 
        #wrapper, #container { padding:0 !important; margin:0 !important; width:100% !important; min-width:100% !important; }
        body { background: #fff !important; padding: 0 !important; overflow-x: hidden; }
        #bo_w { margin: 0 auto !important; width: 100% !important; border:0 !important; }
    </style>';
}
?>

<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/head.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    define('G5_IS_COMMUNITY_PAGE', true);
    include_once(G5_THEME_SHOP_PATH.'/shop.head.php');
    return;
}
include_once(G5_THEME_PATH.'/head.sub.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');
include_once(G5_THEME_PATH.'/modal_quick_consult.php');
?>

<?php
$main_menu = [
  [
    'label' => '간판의뢰',
    'href' => G5_BBS_URL . '/write.php?bo_table=consult',
  ],
  [
    'label' => '포트폴리오',
    'href' => '#',
    'children' => [
      ['label' => '업종별 포트폴리오', 'href' => G5_BBS_URL . '/board.php?bo_table=ca_portfolio'],
      ['label' => '종류별 포트폴리오', 'href' => G5_BBS_URL . '/board.php?bo_table=type_portfolio'],
      ['label' => 'Before&After', 'href' => G5_BBS_URL . '/board.php?bo_table=beforeafter'],
    ]
  ],
  [
    'label' => '간판가이드',
    'href' => '#',
    'children' => [
      ['label' => '간판 종류별 설명', 'href' => G5_BBS_URL . '/board.php?bo_table=signexp'],
      ['label' => '간판 진행 가이드', 'href' => G5_BBS_URL . '/board.php?bo_table=progressguide'],
      ['label' => 'A/S 및 유지보수', 'href' => G5_BBS_URL . '/board.php?bo_table=maintenance'],
      ['label' => '질문 FAQ', 'href' => G5_BBS_URL . '/board.php?bo_table=faq'],
    ]
  ],
  [
    'label' => 'SIGN.ZIP',
    'href' => '#',
    'children' => [
      ['label' => 'SIGN NEWS', 'href' => G5_BBS_URL . '/board.php?bo_table=signnews'],
      ['label' => '고객후기', 'href' => G5_BBS_URL . '/board.php?bo_table=review'],      
    ]
  ],
  [
    'label' => '스토어',
    'href' => G5_BBS_URL . '/board.php?bo_table=store',    
  ],
  [
    'label' => '블로그',
    'href' => 'https://blog.naver.com/sign8319',
    'target' => '_blank'   
  ],
];
?>

<?php
    if(defined('_INDEX_')) { // index에서만 실행
        include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
    }
?>


<div >
    <h1 id="hd_h1"><?php echo $g5['title'] ?></h1>
    <div id="skip_to_container"><a href="#container">본문 바로가기</a></div>

    
  <header class="w-full bg-white/95 backdrop-blur-md shadow-lg sticky top-0 z-50 transition-all duration-300">

    <nav class="bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 w-full mx-auto h-12 sm:h-14 md:h-16 flex items-center justify-center px-4 relative overflow-hidden">
      <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer"></div>
      
      <img
        src="<?php echo G5_THEME_IMG_URL ?>/thumb.png"
        alt="상담 아이콘"
        class="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 mr-2 sm:mr-3 hidden sm:block relative z-10 animate-bounce"
      />
      <span class="text-white text-sm sm:text-base md:text-lg font-bold mr-2 sm:mr-4 relative z-10">
        🔥 고민 하지 마세요!
      </span>
      <div class="relative z-10">
        <a
          href="<?php echo G5_BBS_URL . '/write.php?bo_table=consult'; ?>"
          class="flex items-center bg-white rounded-full shadow-lg px-5 py-2 text-sm font-bold text-orange-600 hover:bg-orange-50 hover:scale-105 transition-all duration-300 ml-2"
        >
          ⚡ 1분 퀵 상담신청
        </a>
      </div>
    </nav>
    
    <style>
      @keyframes shimmer {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
      }
      .animate-shimmer {
        animation: shimmer 3s infinite;
      }
      
      /* 트렌디한 메뉴 호버 효과 */
      .menu-item {
        position: relative;
        transition: all 0.3s ease;
      }
      
      .menu-item:hover {
        color: #f97316 !important;
        transform: translateY(-2px);
      }
      
      .menu-item::after {
        content: '';
        position: absolute;
        bottom: -4px;
        left: 50%;
        transform: translateX(-50%) scaleX(0);
        width: 80%;
        height: 2px;
        background: linear-gradient(90deg, #f97316, #fb923c);
        transition: transform 0.3s ease;
      }
      
      .menu-item:hover::after {
        transform: translateX(-50%) scaleX(1);
      }
      
      /* 드롭다운 메뉴 스타일 */
      .dropdown-menu {
        background: rgba(255, 255, 255, 0.98);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(249, 115, 22, 0.1);
      }
      
      .dropdown-item {
        transition: all 0.2s ease;
      }
      
      .dropdown-item:hover {
        background: linear-gradient(135deg, #f97316 0%, #fb923c 100%) !important;
        color: white !important;
        transform: translateX(4px);
      }
      [x-cloak] { display: none !important; }
    </style>
    <script>
    document.addEventListener('alpine:init', () => {
        Alpine.store('mobileMenu', {
            open: false,
            toggle() {
                this.open = ! this.open;
            },
            close() {
                this.open = false;
            }
        });
    });
    </script>

    <!-- Desktop Header Layout (Hidden on Mobile) -->
    <div class="hidden lg:flex mx-auto items-center justify-center h-20 px-4 container relative">
      <nav class="flex-1">
        <ul class="flex justify-center items-center gap-x-8">
          <?php foreach(array_slice($main_menu, 0, 3) as $item): ?>
            <li class="relative group">
              <?php if ($item['label'] === '간판의뢰'): ?>
                <a href="<?php echo G5_BBS_URL . '/write.php?bo_table=consult'; ?>"
                  class="menu-item text-slate-900 text-lg font-semibold leading-6 transition whitespace-nowrap"
                >
                  <?= $item['label'] ?>
                </a>
              <?php else: ?>
                <a href="<?= $item['href'] ?>"
                   <?php if (!empty($item['target'])) echo 'target="' . $item['target'] . '"'; ?>
                   class="menu-item text-slate-900 text-lg font-semibold leading-6 transition whitespace-nowrap"
                > 
                  <?= $item['label'] ?>
                </a>
              <?php endif; ?>
              <?php if (!empty($item['children'])): ?>
                <ul
                  class="dropdown-menu absolute left-1/2 transform -translate-x-1/2 top-full mt-6 min-w-full rounded-2xl shadow-2xl py-3 px-2 z-20 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all"
                  style="white-space:nowrap"
                >
                  <?php foreach($item['children'] as $child): ?>
                    <li>
                      <a href="<?= $child['href'] ?>"
                         class="dropdown-item block px-4 py-3 text-slate-900 rounded-xl text-base text-center font-medium"
                         <?php if (!empty($child['target'])) echo 'target="' . $child['target'] . '"'; ?>
                      >
                        <?= $child['label'] ?>
                      </a>
                    </li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      </nav>
      
      <a href="<?php echo G5_URL; ?>/index.php" class="flex-shrink-0 flex items-center mx-8">
        <img src="<?php echo G5_THEME_IMG_URL ?>/logo.png" alt="로고" class="h-10 w-auto" />
      </a>
      
      <nav class="flex-1">
        <ul class="flex justify-center items-center gap-x-8">
          <?php foreach(array_slice($main_menu, 3) as $item): ?>
            <li class="relative group">
              <a href="<?= $item['href'] ?>"
                 <?php if (!empty($item['target'])) echo 'target="' . $item['target'] . '"'; ?>
                 class="menu-item text-slate-900 text-lg font-semibold leading-6 transition whitespace-nowrap"
              >
                <?= $item['label'] ?>
              </a>
              <?php if (!empty($item['children'])): ?>
                <ul
                  class="dropdown-menu absolute left-1/2 transform -translate-x-1/2 top-full mt-6 min-w-full rounded-2xl shadow-2xl py-3 px-2 z-20 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all"
                  style="white-space:nowrap"
                >
                  <?php foreach($item['children'] as $child): ?>
                    <li>
                      <a href="<?= $child['href'] ?>"
                         class="dropdown-item block px-4 py-3 text-slate-900 rounded-xl text-base text-center font-medium"
                         <?php if (!empty($child['target'])) echo 'target="' . $child['target'] . '"'; ?>
                      >
                        <?= $child['label'] ?>
                      </a>
                    </li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      </nav>
      
      <div class="absolute right-4 flex flex-col items-end text-slate-900 text-sm font-medium leading-7">
        <?php if ($is_member): ?>
          <a href="<?php echo G5_BBS_URL ?>/logout.php"" class="hover:text-primary">로그아웃</a>
        <?php else: ?>
          <a href="<?php echo G5_BBS_URL ?>/login.php">로그인</a>
          <a href="<?php echo G5_BBS_URL ?>/register.php" class="hover:text-primary">회원가입</a>
        <?php endif; ?>
      </div>
    </div>

    <!-- Mobile Header Layout (Visible on Mobile) -->
    <div class="lg:hidden flex flex-col w-full bg-white" x-data="{ activeMenu: null }">
        <!-- Row 1: Top Bar (Hamburger, Logo, Icons) -->
        <div class="flex items-center justify-between h-14 px-4 border-b border-gray-100">
            <!-- Left: Hamburger -->
            <button class="flex items-center justify-center p-2 -ml-2 text-gray-800" @click="$store.mobileMenu.toggle()">
                <span class="sr-only">메뉴 열기</span>
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
            
            <!-- Center: Logo -->
            <a href="<?php echo G5_URL; ?>/index.php" class="flex-shrink-0">
                <img src="<?php echo G5_THEME_IMG_URL ?>/logo.png" alt="로고" class="h-6 w-auto" />
            </a>

            <!-- Right: Search & Cart Icons -->
            <div class="flex items-center gap-3">
                <button type="button" class="text-gray-800 p-1" onclick="alert('준비 중입니다.')">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </button>
                <a href="https://smartstore.naver.com/ganpandaehak" target="_blank" class="text-gray-800 p-1 relative">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                    </svg>
                </a>
            </div>
        </div>

        <!-- Row 2: Scrollable GNB -->
        <div class="h-12 border-b border-gray-100 overflow-x-auto no-scrollbar bg-white">
            <ul class="flex items-center h-full px-4 gap-4 whitespace-nowrap">
                <?php foreach($main_menu as $item): ?>
                <li>
                    <?php if ($item['label'] === '간판의뢰'): ?>
                        <a href="<?= $item['href'] ?>" 
                           class="inline-block bg-orange-100 text-orange-600 px-3 py-1.5 rounded-full text-[14px] font-bold hover:bg-orange-200 transition-colors">
                            <?= $item['label'] ?>
                        </a>
                    <?php elseif (!empty($item['children'])): ?>
                        <button type="button" 
                                @click="activeMenu = activeMenu === '<?= $item['label'] ?>' ? null : '<?= $item['label'] ?>'"
                                class="text-[15px] font-medium transition-colors"
                                :class="activeMenu === '<?= $item['label'] ?>' ? 'text-orange-500 font-bold' : 'text-gray-600 hover:text-orange-500'">
                            <?= $item['label'] ?>
                        </button>
                    <?php else: ?>
                        <a href="<?= $item['href'] ?>" 
                           <?php if (!empty($item['target'])) echo 'target="' . $item['target'] . '"'; ?>
                           class="text-[15px] font-medium text-gray-600 hover:text-orange-500 transition-colors">
                            <?= $item['label'] ?>
                        </a>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Secondary Submenu Bar -->
        <?php foreach($main_menu as $item): ?>
            <?php if (!empty($item['children'])): ?>
            <div x-show="activeMenu === '<?= $item['label'] ?>'" 
                 class="w-full bg-gray-50 border-b border-gray-100 overflow-x-auto no-scrollbar"
                 x-transition:enter="transition ease-out duration-200"
                 x-transition:enter-start="opacity-0 -translate-y-2"
                 x-transition:enter-end="opacity-100 translate-y-0"
                 style="display: none;">
                <ul class="flex items-center px-4 py-3 gap-4 whitespace-nowrap">
                    <?php foreach($item['children'] as $child): ?>
                    <li>
                        <a href="<?= $child['href'] ?>"
                           <?php if (!empty($child['target'])) echo 'target="' . $child['target'] . '"'; ?>
                           class="text-[13px] text-gray-600 hover:text-orange-500 font-medium bg-white border border-gray-200 px-3 py-1.5 rounded-lg shadow-sm">
                            <?= $child['label'] ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <!-- Mobile Menu Code Removed from here -->
  </header>

    <!-- Alpine.js (Moved from index.php for global access) -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <!-- Mobile Menu Overlay (Backdrop) -->
    <div id="mobileMenuOverlay" x-data x-show="$store.mobileMenu.open" x-cloak
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9990] lg:hidden"
         @click="$store.mobileMenu.close()">
    </div>
    
    <!-- Mobile Menu Panel (Moved outside for fixed positioning) -->
    <div id="mobileMenuPanel" x-data x-show="$store.mobileMenu.open" x-cloak
         x-transition:enter="distransition transform ease-out duration-300"
         x-transition:enter-start="-translate-x-full"
         x-transition:enter-end="translate-x-0"
         x-transition:leave="transition transform ease-in duration-200"
         x-transition:leave-start="translate-x-0"
         x-transition:leave-end="-translate-x-full"
         class="fixed top-0 left-0 h-full w-[70%] max-w-[280px] bg-white shadow-2xl z-[9999] lg:hidden overflow-y-auto flex flex-col font-sans">
        
        <div class="flex items-center justify-between p-5 bg-white sticky top-0 z-10">
            <div class="flex gap-3 text-sm font-medium">
               <?php if (!$is_member): ?>
               <a href="<?php echo G5_BBS_URL ?>/login.php" class="text-gray-900 border-b border-gray-900 pb-0.5">로그인</a>
               <a href="<?php echo G5_BBS_URL ?>/register.php" class="text-gray-500">회원가입</a>
               <?php else: ?>
               <span class="text-gray-900"><b><?php echo $member['mb_nick'] ?></b>님</span>
               <?php endif; ?>
            </div>
            <button @click="$store.mobileMenu.close()" class="p-2 -mr-2 text-gray-800 hover:text-black focus:outline-none transition-colors">
                 <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
        
         <nav class="flex-1 px-0 py-2">
            <ul class="flex flex-col">
                <?php foreach($main_menu as $item): ?>
                <li class="border-b border-gray-200 last:border-b-0">
                    <?php if (!empty($item['children'])): ?>
                        <div x-data="{ open: false }">
                            <button @click="open = !open"
                                    class="w-full text-left px-5 py-3.5 text-gray-800 hover:bg-gray-50 transition flex items-center justify-between text-[14px] font-medium"
                                    :class="{'text-orange-500': open}">
                                <span><?= $item['label'] ?></span>
                                <svg class="w-4 h-4 text-gray-400 transition-transform duration-300" :class="{ 'rotate-180': open }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 9l-7 7-7-7"/>
                                </svg>
                            </button>
                            <ul x-show="open" 
                                x-collapse
                                class="bg-gray-50 py-1 border-t border-gray-100">
                                <?php foreach($item['children'] as $child): ?>
                                <li>
                                    <a href="<?= $child['href'] ?>"
                                       <?php if (!empty($child['target'])) echo 'target="' . $child['target'] . '"'; ?>
                                       class="block px-5 py-2.5 text-gray-500 hover:text-orange-500 transition text-[13px]"
                                       @click="$store.mobileMenu.close()">
                                        - <?= $child['label'] ?>
                                    </a>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?= $item['href'] ?>"
                           <?php if (!empty($item['target'])) echo 'target="' . $item['target'] . '"'; ?>
                           class="block px-5 py-3.5 text-gray-800 hover:bg-gray-50 transition text-[14px] font-medium"
                           @click="$store.mobileMenu.close()">
                            <?= $item['label'] ?>
                        </a>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
            
            <?php if ($is_member): ?>
            <div class="mt-auto p-6 border-t border-gray-100">
                <a href="<?php echo G5_BBS_URL ?>/logout.php" 
                   class="block w-full py-3 bg-gray-100 text-center rounded-lg text-sm text-gray-600 font-medium hover:bg-gray-200 transition"
                   @click="$store.mobileMenu.close()">로그아웃</a>
            </div>
            <?php endif; ?>
        </nav>
    </div>

    
    <script>
    // 모달 열기 및 메뉴 닫기 함수
    function openModalAndCloseMenu() {
        console.log('모달 열기 함수 호출됨');
        
        // 모달 열기 (순수 JavaScript)
        const modalContainer = document.getElementById('modalContainer');
        if (modalContainer) {
            modalContainer.style.display = 'flex';
            console.log('모달 열기 성공');
        }
        
        // 모바일 메뉴 닫기
        const mobileMenuPanel = document.getElementById('mobileMenuPanel');
        const mobileMenuOverlay = document.getElementById('mobileMenuOverlay');
        if (mobileMenuPanel) {
            mobileMenuPanel.classList.add('hidden');
        }
        if (mobileMenuOverlay) {
            mobileMenuOverlay.classList.add('hidden');
        }
        
        console.log('모달 열기 및 메뉴 닫기 완료');
        return false; // 기본 링크 동작 방지
    }
    
    
    $(function() {
        $(".gnb_close_btn, #gnb_all_bg").click(function() {
            $("#gnb_all, #gnb_all_bg").hide();
        });
    });
    </script>
</div>
<hr>

<div id="wrapper">
    <div id="container_wr">

        <div id="container">