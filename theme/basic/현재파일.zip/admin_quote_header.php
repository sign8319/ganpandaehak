<?php
if (!defined('_GNUBOARD_'))
    exit;

/**
 * [STEP 1: 데이터 통합 및 접근 해제] 
 * 통합 헤더 컴포넌트: 견적명, 상호, 고객명, 연락처, 주소 섹션
 * 모든 페이지(1, 2, 3단계)에서 동일한 위치에 보이게 처리
 */
?>
<style>
    :root {
        --primary-color: #FF6B2C;
        --bg-gray: #F8F9FA;
        --border-color: #F1F3F5;
        --text-main: #333D4B;
        --text-sub: #8B95A1;
        --radius: 12px;
        --shadow-soft: 0 8px 30px rgba(0, 0, 0, 0.04);
    }

    .quote-header-card {
        background: #FFFFFF;
        border-radius: var(--radius);
        box-shadow: var(--shadow-soft);
        padding: 40px;
        margin-bottom: 24px;
        border: 1px solid rgba(0, 0, 0, 0.02);
    }

    .step-nav-bar {
        display: flex;
        gap: 12px;
        margin-bottom: 40px;
    }

    .step-nav-item {
        flex: 1;
        padding: 20px;
        background: var(--bg-gray);
        border-radius: var(--radius);
        text-align: center;
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        border: 2px solid transparent;
        text-decoration: none;
        display: block;
    }

    .step-nav-item.active {
        background: #FFF9F5;
        border-color: var(--primary-color);
        transform: translateY(-2px);
    }

    .step-num {
        font-size: 12px;
        font-weight: 600;
        color: #ADB5BD;
        margin-bottom: 6px;
        display: block;
        letter-spacing: 0.5px;
    }

    .step-nav-item.active .step-num {
        color: var(--primary-color);
    }

    .step-txt {
        font-size: 16px;
        color: var(--text-main);
        font-weight: 500;
    }

    .step-nav-item.active .step-txt {
        color: var(--primary-color);
        font-weight: 700;
    }

    .header-grid {
        display: grid;
        grid-template-columns: repeat(12, 1fr);
        gap: 24px;
    }

    .input-group {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .input-label {
        font-size: 14px;
        font-weight: 600;
        color: var(--text-sub);
        margin-left: 2px;
    }

    .input-field {
        height: 52px;
        padding: 0 18px;
        background: var(--bg-gray);
        border: 1px solid transparent;
        border-radius: var(--radius);
        font-size: 15px;
        color: var(--text-main);
        transition: all 0.2s ease;
    }

    .input-field::placeholder {
        color: #ADB5BD;
    }

    .input-field:focus {
        background: #FFFFFF;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 4px rgba(255, 107, 44, 0.1);
        outline: none;
    }

    .btn-zip {
        height: 52px;
        padding: 0 24px;
        background: var(--text-main);
        color: white;
        font-weight: 600;
        border-radius: var(--radius);
        transition: all 0.2s ease;
        font-size: 14px;
    }

    .btn-zip:hover {
        background: #000000;
        transform: translateY(-1px);
    }
</style>

<?php if (!isset($hide_header_inputs) || !$hide_header_inputs): ?>
    <div class="quote-header-card">
        <!-- Step Navigation (Standard Links) -->
        <div class="step-nav-bar">
            <!-- Step 1 Link -->
            <a href="./admin_quote_step1.php?qa_id=<?php echo $qa_id; ?>"
                class="step-nav-item <?php echo (basename($_SERVER['SCRIPT_NAME']) == 'admin_quote_step1.php') ? 'active' : ''; ?>">
                <span class="step-num">Step 01</span>
                <span class="step-txt">현장 실측</span>
            </a>

            <!-- Step 2 Link -->
            <a href="./admin_quote.php?w=form&qa_id=<?php echo $qa_id; ?>"
                class="step-nav-item <?php echo (basename($_SERVER['SCRIPT_NAME']) == 'admin_quote.php') ? 'active' : ''; ?>">
                <span class="step-num">Step 02</span>
                <span class="step-txt">견적 작성</span>
            </a>

            <!-- Step 3 Link -->
            <a href="./admin_customer.php?qa_id=<?php echo $qa_id; ?>"
                class="step-nav-item <?php echo (basename($_SERVER['SCRIPT_NAME']) == 'admin_customer.php') ? 'active' : ''; ?>">
                <span class="step-num">Step 03</span>
                <span class="step-txt">고객 등록</span>
            </a>
        </div>

        <!-- 통합 헤더 정보 -->
        <div class="header-grid">
            <div class="col-span-12 lg:col-span-8 input-group">
                <span class="input-label">견적명 (Project Name)</span>
                <input type="text" name="qa_subject" value="<?php echo htmlspecialchars($quote['qa_subject'] ?? ''); ?>"
                    placeholder="프로젝트명을 입력하세요" class="input-field">
            </div>
            <div class="col-span-12 lg:col-span-4 input-group">
                <span class="input-label">상호 (Business Name)</span>
                <input type="text" name="qa_tax_company_name"
                    value="<?php echo htmlspecialchars($quote['qa_tax_company_name'] ?? ''); ?>" placeholder="사업자명을 입력하세요"
                    class="input-field">
            </div>
            <div class="col-span-12 lg:col-span-4 input-group">
                <span class="input-label">고객명 / 담당자</span>
                <input type="text" name="qa_client_name"
                    value="<?php echo htmlspecialchars($quote['qa_client_name'] ?? ''); ?>" placeholder="실명을 입력해 주세요"
                    class="input-field">
            </div>
            <div class="col-span-12 lg:col-span-4 input-group">
                <span class="input-label">연락처 (Contact)</span>
                <input type="text" name="qa_client_hp" id="qa_client_hp"
                    value="<?php echo htmlspecialchars($quote['qa_client_hp'] ?? ''); ?>" placeholder="010-0000-0000"
                    class="input-field" oninput="formatPhoneNumber(this)">
            </div>
            <div class="col-span-12 lg:col-span-4 input-group">
                <span class="input-label">이메일 (Email)</span>
                <input type="email" name="qa_client_email"
                    value="<?php echo htmlspecialchars($quote['qa_client_email'] ?? ''); ?>" placeholder="example@mail.com"
                    class="input-field">
            </div>
            <div class="col-span-12 lg:col-span-12 input-group mt-2">
                <span class="input-label">시공 주소 (Address)</span>
                <div class="grid grid-cols-12 gap-3">
                    <input type="text" name="qa_client_addr" id="qa_client_addr"
                        value="<?php echo htmlspecialchars($quote['qa_client_addr'] ?? ''); ?>"
                        placeholder="주소 검색 버튼을 이용해 주세요" class="input-field col-span-9" readonly>
                    <button type="button" onclick="execDaumPostcode()" class="btn-zip col-span-3">주소 검색</button>
                </div>
                <input type="text" name="qa_client_addr2" id="qa_client_addr2"
                    value="<?php echo htmlspecialchars($quote['qa_client_addr2'] ?? ''); ?>" placeholder="나머지 상세 주소를 입력하세요"
                    class="input-field mt-1">
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Alpine.js script removed -->
<script>
    // Simple helper if needed
    function formatPhoneNumber(input) {
        var numbers = input.value.replace(/[^0-9]/g, '');
        var formatted = '';
        if (numbers.startsWith('02')) {
            if (numbers.length < 3) formatted = numbers;
            else if (numbers.length < 6) formatted = numbers.slice(0, 2) + '-' + numbers.slice(2);
            else if (numbers.length < 10) formatted = numbers.slice(0, 2) + '-' + numbers.slice(2, 5) + '-' + numbers.slice(5);
            else formatted = numbers.slice(0, 2) + '-' + numbers.slice(2, 6) + '-' + numbers.slice(6, 10);
        } else {
            if (numbers.length < 4) formatted = numbers;
            else if (numbers.length < 7) formatted = numbers.slice(0, 3) + '-' + numbers.slice(3);
            else if (numbers.length < 11) formatted = numbers.slice(0, 3) + '-' + numbers.slice(3, 6) + '-' + numbers.slice(6);
            else formatted = numbers.slice(0, 3) + '-' + numbers.slice(3, 7) + '-' + numbers.slice(7, 11);
        }
    }
    input.value = formatted;
    }
</script>